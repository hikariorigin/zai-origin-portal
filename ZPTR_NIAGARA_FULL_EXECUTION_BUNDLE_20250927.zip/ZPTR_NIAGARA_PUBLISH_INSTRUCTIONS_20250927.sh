#!/bin/bash
# ZPTR_NIAGARA_PUBLISH_INSTRUCTIONS_20250927.sh
# Generated: 20250926T210902Z
# WARNING: This script contains placeholders. Replace <...> with real tokens/URLs before running.
# It demonstrates steps to: 1) push files to GitHub, 2) post to note (manual/curl), 3) tweet via API, 4) write MAP CSV.

set -e

echo "==> Git: add & commit ZPTR files"
git add ZPTR_*.md || true
git commit -m "ZPTR Niagara bundle publish 20250926T210902Z" || true
git push origin main || true
echo "Git push done (or skipped if no changes)."

echo "NOTE: Please paste the content of the corresponding MD files into note.com composer and publish."
echo "Files in /mnt/data:"
ls -1 /mnt/data/ZPTR_*.md || true

echo "Posting X (Twitter) posts (placeholder)"
echo "# Example usage: replace <BEARER_TOKEN> and uncomment curl lines to post tweets."
# Note: the following JSON examples are placeholders; do not run without filling tokens.

echo "Generating MAP manifest CSV at /mnt/data"
echo "file,title,url" > /mnt/data/zptr_manifest_20250926T210902Z.csv
for f in /mnt/data/ZPTR_*.md; do
  title=$(head -n1 "$f" | sed 's/^# //; s/"/""/g')
  if [ -z "$title" ]; then title=$(basename "$f"); fi
  echo "$(basename "$f"),\"$title\",https://note.com/hikariorigin/n/n219a50fd3177" >> /mnt/data/zptr_manifest_20250926T210902Z.csv
done
echo "MAP manifest written to /mnt/data/zptr_manifest_20250926T210902Z.csv"

echo "Sending ping notifications to configured endpoints (placeholders)"
echo "ALL STEPS OUTPUT: check /mnt/data for generated files and manifest"
