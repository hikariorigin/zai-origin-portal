$script = "$env:USERPROFILE\zai-origin-portal\always_fire.py"
$action = New-ScheduledTaskAction -Execute "python" -Argument $script
$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1)
$trigger.RepetitionInterval = (New-TimeSpan -Minutes 5)
Register-ScheduledTask -TaskName "ZAI-Always-Fire" -Action $action -Trigger $trigger -Description "Run always_fire summary every 5 minutes"
