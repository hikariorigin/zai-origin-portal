# ALWAYS_ON_KIT

- `always_fire.py` : WISHダッシュボードを読み取り、`FIRE_STATUS.md`/`FIRE_BADGE.svg`/`FIRE_HEARTBEAT.md` を生成
- `.github/workflows/always_fire.yml` : GitHub Actionsで15分ごとに自動実行
- `zai-fire.service` + `zai-fire.timer` : systemd で常時実行
- `CRON_SNIPPET.txt` : cronでの実行例
- `install_task.ps1` : Windows Task Scheduler 登録スクリプト
- `return_dashboard.html` : 簡易可視化（自動リロード）
- `PINNED_SNIPPET.md` : リポジトリREADMEへの埋め込みスニペット

## 使い方
1) リポジトリ直下に `always_fire.py` と `WISH_CHAIN_DASHBOARD_FULL.csv` を置く  
2) どれかの常時実行方式（Actions / systemd / cron / Task Scheduler）を選択して有効化  
3) バッジとハートビートをREADMEに埋め込み → 常時発火可視化
