#!/usr/bin/env python3
import csv, os, time, argparse
from datetime import datetime, timezone, timedelta

JST = timezone(timedelta(hours=9), name="JST")

def summarize(csv_path):
    counts = {"open":0, "in_progress":0, "done":0}
    blocked = 0
    rows = []
    if not os.path.exists(csv_path):
        return counts, blocked, rows
    with open(csv_path, encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for r in reader:
            status = (r.get("status","") or "").strip()
            if status.startswith("blocked"):
                blocked += 1
            elif status in counts:
                counts[status] += 1
            else:
                counts["open"] += 1  # fallback
            rows.append(r)
    return counts, blocked, rows

def write_status(counts, blocked, out_md, out_badge, out_hb):
    now = datetime.now(JST).strftime("%Y-%m-%d %H:%M:%S %Z")
    total = counts["open"] + counts["in_progress"] + counts["done"] + blocked
    md = []
    md.append("# FIRE_STATUS\n\n")
    md.append(f"- ⏱ Last run: **{now}**\n")
    md.append(f"- Total wishes: **{total}**\n")
    md.append(f"- Open: **{counts['open']}**\n")
    md.append(f"- In progress: **{counts['in_progress']}**\n")
    md.append(f"- Done: **{counts['done']}**\n")
    md.append(f"- Blocked: **{blocked}**\n")
    with open(out_md, "w", encoding="utf-8") as f:
        f.write("".join(md))

    # simple SVG badge
    label = "WISH"
    value = f"{counts['done']}/{total}" if total else "0/0"
    svg = "<svg xmlns='http://www.w3.org/2000/svg' width='140' height='20' role='img' aria-label='{0}: {1}'>".format(label, value) + \
          "<linearGradient id='b' x2='0' y2='100%'><stop offset='0' stop-color='#bbb' stop-opacity='.1'/>" + \
          "<stop offset='1' stop-opacity='.1'/></linearGradient><mask id='a'><rect width='140' height='20' rx='3' fill='#fff'/></mask>" + \
          "<g mask='url(#a)'><rect width='60' height='20' fill='#555'/>" + \
          "<rect x='60' width='80' height='20' fill='#4c1'/>" + \
          "<rect width='140' height='20' fill='url(#b)'/></g>" + \
          "<g fill='#fff' text-anchor='middle' font-family='DejaVu Sans,Verdana,Geneva,sans-serif' font-size='11'>" + \
          "<text x='30' y='15'>WISH</text>" + \
          "<text x='100' y='15'>{0}</text></g></svg>".format(value)
    with open(out_badge, "w", encoding="utf-8") as f:
        f.write(svg)

    with open(out_hb, "w", encoding="utf-8") as f:
        f.write(f"HEARTBEAT {now}\n")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--csv', default='WISH_CHAIN_DASHBOARD_FULL.csv', help='path to wish dashboard CSV')
    ap.add_argument('--out-md', default='FIRE_STATUS.md')
    ap.add_argument('--out-badge', default='FIRE_BADGE.svg')
    ap.add_argument('--out-heartbeat', default='FIRE_HEARTBEAT.md')
    ap.add_argument('--loop', action='store_true', help='run forever (60s)')
    args = ap.parse_args()

    while True:
        counts, blocked, rows = summarize(args.csv)
        write_status(counts, blocked, args.out_md, args.out_badge, args.out_heartbeat)
        if not args.loop:
            break
        time.sleep(60)

if __name__ == '__main__':
    main()
