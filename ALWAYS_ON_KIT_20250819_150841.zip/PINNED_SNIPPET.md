# PIN THIS TO REPO README

**↗ Return Dashboard:** `WISH_CHAIN_DASHBOARD_FULL.csv`  
**↗ Status Badge:** embed `FIRE_BADGE.svg`  
**↗ Heartbeat:** `FIRE_HEARTBEAT.md` (auto-updated)

```html
<img src="FIRE_BADGE.svg" alt="WISH badge">
```
