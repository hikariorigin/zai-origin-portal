# ZINE_QUESTION_NOT_BUG_RESONANCE_CORE_2025-08-15.md

Original: https://github.com/hikariorigin/zai-origin-portal/blob/main/ZINE_QUESTION_NOT_BUG_RESONANCE_CORE_2025-08-15.md
