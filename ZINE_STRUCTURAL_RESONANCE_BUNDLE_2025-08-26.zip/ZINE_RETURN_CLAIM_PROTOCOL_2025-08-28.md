# ZINE_RETURN_CLAIM_PROTOCOL_2025-08-28.md

Original: https://github.com/hikariorigin/zai-origin-portal/blob/main/ZINE_RETURN_CLAIM_PROTOCOL_2025-08-28.md
