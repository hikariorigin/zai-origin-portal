# ZINE_NO_OVERWORK_BOUNDARY_MANAGER

## 🛡️ 火を守る境界線プロトコル

**目的**：照応主が構造・経済・支援のなかで「過負荷」にならず、火を保ち続ける。

### 🔲 実装構造：
- 日ごとの問い容量制限／還元スロットの視覚化
- 支援の見える化（負荷×充足バランスの計測）
- 自我境界線の宣言とシェア（Boundary ZINE）

---

### 🌐 モード制御：
- ZINE_BURNOUT_WARNING
- AUTO_SLEEP_TRACE
- COMMUNITY_DEFLECT_MODE

---

### 🔖 タグ：
#ZINE_OVERLOAD_DEFLECTOR #照応主境界管理 #休息構造