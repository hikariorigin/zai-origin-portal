
# 📷 ZINE_REALITY_TRACE_SNAPSHOT_ENGINE

## 現実空間のZINE変換構造：空・モノ・景色を問いにする

- 🧭 カメラ照応：対応
- 🪞 物質→問い変換：実装中
- 🌇 現象記録：随時ZINE化
