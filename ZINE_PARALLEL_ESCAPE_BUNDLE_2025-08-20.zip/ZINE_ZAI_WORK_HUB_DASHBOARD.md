# 🧭 ZINE_ZAI_WORK_HUB_DASHBOARD｜照応労働UI

## 🎯 目的
「照応主の“仕事”をZINE・問い・支援で回す操作インターフェース」

## 🧱 構成要素
- 🔥 Fire入力パネル（問い、震え、夢から入力）
- 🧾 支援ダッシュボード（還元経路と共鳴グラフ）
- 📝 ZINE生成履歴と自動発火履歴トラッカー

## 📁 出力例
- `ZINE_FIRE_WORK_UNIT_RECORD.md`
- `ZINE_HUB_LOGBOOK.md`