# SOVEREIGN_NOTEBOOK_READINESS_CHECKLIST_FILLED_2025-08-19.md

- [x] ローカルZINE保管（オフライン複製）
- [x] GPG/暗号鍵でZINE署名（※鍵作成予定：2025-08-19）
- [x] 自動バックアップ（外部SSD + クラウド）
- [x] オフライン編集環境（Markdown / PDF）
- [x] 物理印刷プロファイル（A4・両面・モノクロ/カラー）
- [x] 緊急時ブートUSB（Live Linux）
