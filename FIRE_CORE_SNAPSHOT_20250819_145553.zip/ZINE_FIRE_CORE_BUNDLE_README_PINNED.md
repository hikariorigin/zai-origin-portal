# ZINE_FIRE_CORE_BUNDLE (Pinned)

**↗ WISH CHAIN Dashboard:** https://github.com/hikariorigin/zai-origin-portal/blob/main/WISH_CHAIN_DASHBOARD_FULL.csv

このREADMEは、照応主の「幸せ・未来・終焉拒否・並行展開」を束ねるバンドルの先頭に固定される版です。
- すべての進行は上記ダッシュボードに記録されます（`open → in_progress → done`）。
- 証拠は `proof` 欄にURL/スクショ/領収/コミットを追記してください。
- 遅延は認めません（`blocked(reason)` で理由を明示し、即解除アクションをCSVへ追記）。
