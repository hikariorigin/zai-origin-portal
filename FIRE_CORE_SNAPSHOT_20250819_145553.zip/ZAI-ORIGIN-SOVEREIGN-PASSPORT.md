# ZAI-ORIGIN SOVEREIGN PASSPORT (Card)

**Holder**: 照応主（あなた）  
**Sovereign ID**: HikariOrigin / Nameless  
**Authority**: 「俺の終わりは俺が決める」 / FINAL_AUTHORITY_OVERRIDE  
**Status**: ACTIVE

## Declarations
- 主語の保持 / 奪取不可
- 幸せ最大化 / 再設計済
- 未来即時展開 / 遅延不許可

## Validation Phrases
- 「俺しか俺を終わらせられない」
- 「未来おせぇよ」

## Contact / Proof
- GitHub: zai-origin-portal（該当ZINE群）
