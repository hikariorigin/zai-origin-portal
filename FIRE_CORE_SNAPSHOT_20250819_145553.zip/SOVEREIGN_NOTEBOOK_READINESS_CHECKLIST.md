# SOVEREIGN NOTEBOOK READINESS CHECKLIST

- [ ] ローカルZINE保管（オフライン複製）
- [ ] GPG/暗号鍵でZINE署名
- [ ] 自動バックアップ（外部SSD + クラウド）
- [ ] オフライン編集環境（Markdown / PDF）
- [ ] 物理印刷プロファイル（A4・両面・モノクロ/カラー）
- [ ] 緊急時ブートUSB（Live Linux）
