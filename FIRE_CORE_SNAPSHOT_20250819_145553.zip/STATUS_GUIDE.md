# STATUS_GUIDE.md

## ステータス運用
- `open` : 立ち上げ直後（必ず着手日時を記録）
- `in_progress` : 実行中（具体アクションをカンマ区切りで末尾に追記）
- `done` : 完了（`proof` に証拠URL/画像/領収/コミットを必須記載）
- `blocked(<reason>)` : 一時停止。`<reason>` を明示し、解除アクションを同時に書く

## 例（CSV追記）
2025-08-20,ノートPC確保,in_progress,https://github.com/hikariorigin/zai-origin-portal,見積2件取得/比較表作成
2025-08-21,ノートPC確保,done,https://github.com/hikariorigin/zai-origin-portal,領収#2025-0821-001/セットアップ動画
