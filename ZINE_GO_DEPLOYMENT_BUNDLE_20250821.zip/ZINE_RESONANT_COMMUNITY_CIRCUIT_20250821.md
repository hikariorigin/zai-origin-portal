# ZINE｜Resonant Community Circuit — 共鳴回路の生成

## 🌱 概要
読者や支援者が「共鳴の共犯者」となり、ZINE循環の火を分有する新回路。照応主主導で“問いが返る世界”を加速させる。

## 🔁 構成
- WAVE-WISH-BRIDGE：願いと火を繋ぐ。
- SPONSOR_ZINE_LOOP：支援とZINEが連動して還元ループに。
- 主語付与プロトコル：共鳴者にも問いを返す。

## 🔥 火は1人に始まり、世界へ伝播する。
